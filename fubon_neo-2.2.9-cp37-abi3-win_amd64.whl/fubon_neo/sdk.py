import atexit
import weakref

from fubon_neo._fubon_neo import (
    CoreSDK,
    Order,
    Condition,
    ConditionDayTrade,
    ConditionOrder,
    FutOptOrder,
    FutOptConditionOrder,
)
from .adapter import build_websocket_client, build_rest_client, Mode
from fugle_marketdata import FugleAPIError

class MarketData:
    def __init__(self, sdk_token, mode, version=None):
        self.websocket_client = build_websocket_client(mode, sdk_token, version)
        self.rest_client = build_rest_client(sdk_token)

class FubonSDK(CoreSDK):
    """
    fubon sdk for api trading
    """

    def __init__(self, *args, **kwargs):
        # CoreSDK is built in __new__; this only installs the shutdown hook.
        #
        # The background callback thread has to stop before Py_Finalize gets
        # going. CPython runs atexit callbacks from call_py_exitfuncs(), which
        # happens before _PyRuntimeState_SetFinalizing() -- the interpreter is
        # still whole there. Leaving it to __del__ is too late: by then any
        # thread asking for the GIL is killed with pthread_exit, and that
        # unwind through Rust frames aborts the process.
        #
        # Weak reference so the hook cannot be what keeps the SDK alive; if the
        # object is already gone its shutdown has run. Its callback fires when
        # the SDK is collected and drops the hook from the atexit list, so
        # services that rebuild the SDK (reconnect loops) do not accumulate
        # dead entries. The closure is late-binding, so referencing
        # _shutdown_at_exit before its def is fine.
        ref = weakref.ref(self, lambda _: atexit.unregister(_shutdown_at_exit))

        def _shutdown_at_exit():
            sdk = ref()
            if sdk is not None:
                sdk.shutdown()

        atexit.register(_shutdown_at_exit)

    def init_realtime(self, mode = Mode.Speed, version = None):
        """
        Initial market data and get authorised

        Args:
            mode: Speed or Normal mode
            version: Optional per-product WebSocket streaming version mapping.
                Omitted, or omitted for a product, means that product's latest:
                futopt v1.1 (trial-matching frames carrying ``isTrial: true`` on
                the trades/books channels) and stock v1.0. Pass
                ``version={'futopt': 'v1.0'}`` to stay on futopt v1.0 and not
                receive those frames. Only the mapping form is accepted; a plain
                string raises, as does asking for a version a product does not
                serve (stock only serves v1.0).

        After this returns, ``marketdata.websocket_client.futopt.url`` reports
        the endpoint that was actually resolved -- the version segment comes
        from here, not from anything the caller wrote, so that is the way to
        confirm which version a client ended up on.
        """
        sdk_token = super().exchange_realtime_token()
        self.marketdata = MarketData(sdk_token, mode, version)
